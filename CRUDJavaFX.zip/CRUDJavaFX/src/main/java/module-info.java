module com.example.crudjavafx {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.crudjavafx to javafx.fxml;
    exports com.example.crudjavafx;

    opens com.example.crudjavafx.controller to javafx.fxml;
    exports com.example.crudjavafx.controller;

    opens com.example.crudjavafx.model to javafx.base;
    exports com.example.crudjavafx.model;
}