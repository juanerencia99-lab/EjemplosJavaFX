package com.example.crudjavafx.controller;

import java.net.URL;
import java.util.ResourceBundle;

import com.example.crudjavafx.model.Persona;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;

public class PersonasController implements Initializable{

    @FXML
    private Button btnAdd;

    @FXML
    private Button btnDelete;

    @FXML
    private Button btnEdit;

    @FXML
    private TextField campoApellidos;

    @FXML
    private TextField campoEdad;

    @FXML
    private TextField campoNombre;

    @FXML
    private TableColumn<Persona,String> colApellidos;

    @FXML
    private TableColumn<Persona,Integer> colEdad;

    @FXML
    private TableColumn<Persona,String> colNombre;

    @FXML
    private TableView<Persona> tablaPersonas;
    
    private ObservableList<Persona> listaPersonas;
    
    private Persona registro;

    @FXML
    void AddPersona(ActionEvent event) 
    {
    	try
    	{
	    	String nombre = this.campoNombre.getText();
	    	String apellidos = this.campoApellidos.getText();
	    	int edad = Integer.parseInt(this.campoEdad.getText());
	    	
	    	Persona p = new Persona(nombre, apellidos, edad);
	    	
	    	if(this.listaPersonas.contains(p)==false)
	    	{    		    		
	    		this.aviso("Persona añadida correctamente", AlertType.CONFIRMATION);
	        	this.listaPersonas.add(p);
	        	this.resetFormulario();
	        	//this.tablaPersonas.refresh();
	    	}
	    	else
	    	{
	    		this.aviso("La persona ya existe.", AlertType.ERROR);
	    	}
    	}
    	catch(NumberFormatException e)
    	{
    		this.aviso("La edad tiene que ser un número.", AlertType.ERROR);
    	}
    	catch(Exception e)
    	{
    		this.aviso(e.getMessage(), AlertType.ERROR);
    	}
    }

    @FXML
    void DeletePersona(ActionEvent event) 
    {
    	if(this.registro == null)
    	{
    		this.aviso("No has seleccionado ninguna persona.", AlertType.ERROR);
    	}
    	else
    	{
    		this.listaPersonas.remove(this.registro);
    		
    		this.resetFormulario();
    		
    		this.aviso("Persona eliminada correctamente.", AlertType.CONFIRMATION);
    		        	
    		//this.tablaPersonas.refresh();
    	}
    }

    @FXML
    void EditPersona(ActionEvent event) 
    {
    	if(this.registro == null)
    	{
    		this.aviso("No has seleccionado ninguna persona.", AlertType.ERROR);
    	}
    	else
    	{
    		try
    		{
	    		String nombre = this.campoNombre.getText();
	        	String apellidos = this.campoApellidos.getText();
	        	int edad = Integer.parseInt(this.campoEdad.getText());
	        	
	        	this.registro.setNombre(nombre);
	        	this.registro.setApellidos(apellidos);
	        	this.registro.setEdad(edad);
	        	
	        	this.tablaPersonas.refresh();
	        	
	        	this.resetFormulario();
	        	
	        	this.aviso("Persona modificada correctamente.", AlertType.CONFIRMATION);
	        	
    		}
    		catch(NumberFormatException e)
        	{
        		this.aviso("La edad tiene que ser un número.", AlertType.ERROR);
        	}
    		catch(Exception e)
    		{
    			this.aviso(e.getMessage(), AlertType.ERROR);
    		}
    	}
    }

    @FXML
    void Seleccionar(MouseEvent event) 
    {
    	
    	this.registro = this.tablaPersonas.getSelectionModel().getSelectedItem();
    	
    	if(registro!=null)
    	{
    		this.campoNombre.setText(this.registro.getNombre());
    		this.campoApellidos.setText(this.registro.getApellidos());
    		this.campoEdad.setText(Integer.toString(this.registro.getEdad()));
    	}
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
		listaPersonas = FXCollections.observableArrayList();
		this.colNombre.setCellValueFactory(new PropertyValueFactory<Persona,String>("nombre"));
		this.colApellidos.setCellValueFactory(new PropertyValueFactory<Persona,String>("apellidos"));
		this.colEdad.setCellValueFactory(new PropertyValueFactory<Persona,Integer>("edad"));
    
		this.tablaPersonas.setItems(listaPersonas);
    } 
    
    private void resetFormulario()
    {
    	this.campoNombre.setText("");
		this.campoApellidos.setText("");
		this.campoEdad.setText("");
		this.registro = null;
		this.tablaPersonas.getSelectionModel().select(null);
    }
    
    private void aviso(String aviso, AlertType tipo)
    {
    	Alert a = new Alert(tipo);
    	a.setTitle("Aviso...");
    	a.setHeaderText(aviso);
    	a.show();
    }
}