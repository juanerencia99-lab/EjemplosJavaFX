package com.example.crudjavafx;

public class LanzadoraMain {

	public static void main(String[] args) {
		MainApp.main(args);
	}

}
