package com.example.crudjavafx.view;

public interface LocalizadorRecursos {
}
