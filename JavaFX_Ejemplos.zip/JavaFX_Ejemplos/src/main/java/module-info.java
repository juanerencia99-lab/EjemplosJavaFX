module com.example.javafx_ejemplos {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.web;
    requires javafx.swing;

    opens javafx;
    opens javafx.ejecutarejemplos;
    opens javafx.aplicacionfxml.controladores;
    opens javafx.comunicacionventanas.controladores;

    exports javafx.ejecutarejemplos;
    exports javafx.aplicacionfxml.controladores;
    exports javafx.comunicacionventanas.controladores;
}