package calculadoraFx;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class CalculadoraFx extends Application
{
	private class PulsaResta implements EventHandler<ActionEvent> {

		@Override
		public void handle(ActionEvent event) {
			restar();
		}
		
	}
	
	private TextField operando1;
	private TextField operando2;
	private TextField resultado;
	
	public static void main(String[] args) 
	{
	    launch(args);
	}
	    
	@Override
	public void start(Stage escenarioPrincipal) throws Exception 
	{
		try {
			VBox raiz = new VBox();
			raiz.setPadding(new Insets(10));
			raiz.setSpacing(10);
			raiz.setAlignment(Pos.CENTER);
			
			Label titulo = new Label("Calculadora");
			titulo.setFont(Font.font(20));
			
			operando1 = new TextField();
			operando1.setFont(Font.font(20));
			operando1.setAlignment(Pos.CENTER);
			
			operando2 = new TextField();
			operando2.setFont(Font.font(20));
			operando2.setAlignment(Pos.CENTER);
			
			HBox panelBotones = new HBox();
			panelBotones.setPadding(new Insets(10));
			panelBotones.setSpacing(10);
			panelBotones.setAlignment(Pos.CENTER);
			
			Button botonSuma = new Button();
	    	botonSuma.setText("+");
	    	botonSuma.setAlignment(Pos.CENTER);
	    	botonSuma.setFont(Font.font(20));
	    	
	    	botonSuma.setOnAction(new EventHandler<ActionEvent>() {
	            
	            @Override
	            public void handle(ActionEvent event) {
	                sumar();
	            }
	        });
	    	
	    	Button botonResta = new Button();
	    	botonResta.setText("-");
	    	botonResta.setAlignment(Pos.CENTER);
	    	botonResta.setFont(Font.font(20));
	    	
	    	botonResta.setOnAction(new PulsaResta());
	    	
	    	Button botonMultiplicacion = new Button();
	    	botonMultiplicacion.setText("*");
	    	botonMultiplicacion.setAlignment(Pos.CENTER);
	    	botonMultiplicacion.setFont(Font.font(20));
	    	
	    	botonMultiplicacion.setOnAction(e -> multiplicar(/*e*/));
	    	
	    	Button botonDivision = new Button();
	    	botonDivision.setText("/");
	    	botonDivision.setAlignment(Pos.CENTER);
	    	botonDivision.setFont(Font.font(20));
	    	
	    	botonDivision.setOnAction(e -> {
	    		dividir();
	    	});
	    	
	    	panelBotones.getChildren().addAll(botonSuma,botonResta,botonMultiplicacion,botonDivision);
			
			resultado = new TextField();
			resultado.setFont(Font.font(20));
			resultado.setAlignment(Pos.CENTER);
			resultado.setEditable(false);
									
			raiz.getChildren().addAll(titulo, operando1,panelBotones, operando2, resultado);
			
			Scene escena = new Scene(raiz, 400, 400);
			escenarioPrincipal.setTitle("Calculadora");
			escenarioPrincipal.setScene(escena);
			escenarioPrincipal.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	private void sumar()
	{
		int op1 = Integer.parseInt(operando1.getText());
		int op2 = Integer.parseInt(operando2.getText());
		int res = op1 + op2;
		resultado.setText(Integer.toString(res));
	}
	
	private void restar()
	{
		int op1 = Integer.parseInt(operando1.getText());
		int op2 = Integer.parseInt(operando2.getText());
		int res = op1 - op2;
		resultado.setText(Integer.toString(res));
	}
	
	private void multiplicar(/*ActionEvent event*/)
	{
		int op1 = Integer.parseInt(operando1.getText());
		int op2 = Integer.parseInt(operando2.getText());
		int res = op1 * op2;
		resultado.setText(Integer.toString(res));
	}
	
	private void dividir()
	{
		double op1 = Double.parseDouble(operando1.getText());
		double op2 = Double.parseDouble(operando2.getText());
		if(op2!=0)
		{
			double res = op1 / op2;
			resultado.setText(Double.toString(res));
		}
		else
		{
			resultado.setText("Error!!!");
		}
	}
}
