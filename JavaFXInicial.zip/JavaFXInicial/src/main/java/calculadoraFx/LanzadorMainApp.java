package calculadoraFx;

public class LanzadorMainApp {

	public static void main(String[] args) {
		CalculadoraFx.main(args);
	}

}
