package holaMundoFx;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ColorPicker;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.web.WebView;
import javafx.stage.Stage;

public class HolaMundoFx extends Application
{		
	private int contador;

	public static void main(String[] args) 
	{
	    launch(args);
	}
	    
	@Override
	public void start(Stage escenarioPrincipal) throws Exception 
	{
		try {
/*
			contador = 0;
			VBox raiz = new VBox();
			raiz.setPadding(new Insets(10));
			raiz.setSpacing(10);
			raiz.setAlignment(Pos.CENTER);
			
			Label saludo1 = new Label("Hola Don Pepito!!!");
			saludo1.setFont(Font.font(20));
			
			Label saludo2 = new Label();
			saludo2.setFont(Font.font(20));
			
			Button botonSaludo = new Button();
			botonSaludo.setText("Ehhh...");
			botonSaludo.setAlignment(Pos.CENTER);
			botonSaludo.setFont(Font.font(20));
	    	
			botonSaludo.setOnAction(new EventHandler<ActionEvent>() {
	            
	            @Override
	            public void handle(ActionEvent event) {
	            	contador++;
	                saludo2.setText(Integer.toString(contador));
	            }
	        });
				  
			ColorPicker colorPicker = new ColorPicker();
			
			raiz.getChildren().addAll(saludo1,botonSaludo,saludo2,colorPicker);

			Scene escena = new Scene(raiz, 800, 800);
			escenarioPrincipal.setTitle("Hola Mundo");
			escenarioPrincipal.setScene(escena);
			escenarioPrincipal.show();
*/

			WebView webView = new WebView();

	        webView.getEngine().load("https://www.acremar.es");

	        VBox panel = new VBox(webView);
			
			Scene escena = new Scene(panel, 800, 800);
			escenarioPrincipal.setTitle("Hola Mundo");
			escenarioPrincipal.setScene(escena);
			escenarioPrincipal.show();


		} catch(Exception e) {
			e.printStackTrace();
		}
	}
}
