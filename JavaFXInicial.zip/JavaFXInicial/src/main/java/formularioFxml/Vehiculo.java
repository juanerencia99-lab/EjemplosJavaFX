package formularioFxml;

import java.util.Objects;

public class Vehiculo 
{
	private String marca;
	private String matricula;
	private int cc;
	private String motor;
	
	public Vehiculo()
	{
		this.marca = "";
		this.matricula = "";
		this.cc = 0;
		this.motor = "";
	}
	
	public Vehiculo(String marca, String matricula, int cc, String motor)
	{
		this.setMarca(marca);
		this.setMatricula(matricula);
		this.setCC(cc);
		this.setMotor(motor);
	}
	
	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public int getCC() {
		return cc;
	}

	public void setCC(int cc) {
		this.cc = cc;
	}

	public String getMotor() {
		return motor;
	}

	public void setMotor(String motor) {
		this.motor = motor;
	}
	
	@Override
	public String toString() {
		return "Vehiculo [marca=" + marca + ", matricula=" + matricula + ", cc=" + cc + ", motor="
				+ motor + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(cc, marca, matricula, motor);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Vehiculo other = (Vehiculo) obj;
		return cc == other.cc && Objects.equals(marca, other.marca)
				&& Objects.equals(matricula, other.matricula) && Objects.equals(motor, other.motor);
	}
}
