package formularioFxml;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Slider;
import javafx.scene.control.TextField;

public class Controlador implements Initializable{

    @FXML
    private Button btnGuardar;

    @FXML
    private Slider campoCC;

    @FXML
    private TextField campoMarca;

    @FXML
    private TextField campoMatricula;

    @FXML
    private ChoiceBox<String> campoMotor;

    @FXML
    void GuardarVehiculo(ActionEvent event) 
    {
    	String marca = campoMarca.getText();
    	String matricula = campoMatricula.getText();
    	int cc = (int)campoCC.getValue();
    	String motor = campoMotor.getSelectionModel().getSelectedItem();
    	
    	Vehiculo v = new Vehiculo(marca,matricula, cc, motor);
    	
    	Alert a = new Alert(AlertType.INFORMATION);
    	a.setTitle("Aviso...");
    	a.setContentText(v.toString());
    	a.setHeaderText("Vehículo creado correctamente!!!");
    	a.showAndWait();
    	System.out.println("Espero a cerrar el aviso.");
    	//a.show();
    	//System.out.println("No espero.");
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
		campoMotor.getItems().add("Gasolina");
		campoMotor.getItems().add("Diesel");
		
		/*campoCC.setMin(0);
		campoCC.setMax(3000);
		campoCC.setMajorTickUnit(500.0);
		campoCC.setMinorTickCount(5);
		campoCC.setShowTickMarks(true);
		campoCC.setShowTickLabels(true);*/
    } 
}
