package holaMundoFxml;

import java.util.ResourceBundle;

import java.net.URL;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;

public class Controlador implements Initializable{

	@FXML
	private Label saludo;
	
	@FXML
	private Label despedida;
	
	@Override
    public void initialize(URL url, ResourceBundle rb) {
		saludo.setText("Hola Don Pepito!!!");
        despedida.setText("Adiós Don José!!!");
    }   
}
