package holaMundoFxml;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class HolaMundoFxml extends Application {
	
	public static void main(String[] args) {
		launch(args);
	}
	
	@Override
	public void start(Stage escenarioPrincipal) {
		try {
			FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("HolaMundoFxml.fxml"));
			Parent raiz = fxmlLoader.load();
			Scene escena = new Scene(raiz);
			escenarioPrincipal.setTitle("Saludo");
			escenarioPrincipal.setScene(escena);
			escenarioPrincipal.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
}