package eventosFx;

import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class EventosFx extends Application
{
    @Override
    public void start(Stage primaryStage)
    {
        try {
            ChoiceBox<String> choiceBox = new ChoiceBox<>();
            choiceBox.getItems().addAll("Rojo", "Verde", "Azul");
            choiceBox.setValue("Rojo"); // Valor inicial

            // Listener para cambios de selección
            choiceBox.getSelectionModel().selectedItemProperty().addListener(
                    (observable, oldValue, newValue) -> {
                        System.out.println("Valor anterior: " + oldValue);
                        System.out.println("Nuevo valor: " + newValue);
                    }
            );

            /// Lo mismo pero sin Lambda

            choiceBox.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {
                @Override
                public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                    System.out.println("Antes: " + oldValue);
                    System.out.println("Después: " + newValue);
                }
            });

            Button boton = new Button();
            boton.setText("Boton");

            boton.setOnAction(e -> {System.out.println("Boton pulsado"); });

            /// Lo mismo pero sin Lambda
            boton.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    System.out.println("Boton pulsado");
                }
            });

            VBox root = new VBox(10, choiceBox, boton);
            Scene scene = new Scene(root, 300, 200);
            primaryStage.setScene(scene);
            primaryStage.setTitle("Ejemplo Eventos");
            primaryStage.show();
        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}