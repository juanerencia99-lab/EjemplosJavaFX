package eventosFx;

public class LanzadorMainApp {

	public static void main(String[] args) {
		EventosFx.main(args);
	}

}
