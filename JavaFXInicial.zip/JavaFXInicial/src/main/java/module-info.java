module com.example.javafxinicial {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.web;
    requires javafx.graphics;

    opens calculadoraFx;
    opens holaMundoFx;
    opens eventosFx;
    opens calculadoraFxml;
    opens holaMundoFxml;
    opens formularioFxml;
}