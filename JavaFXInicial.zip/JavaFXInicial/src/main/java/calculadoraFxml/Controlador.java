package calculadoraFxml;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class Controlador {

	@FXML
	private Button botonSuma;
	
	@FXML
	private Button botonResta;
	
	@FXML
	private Button botonMultiplicacion;
	
	@FXML
	private Button botonDivision;
	
	@FXML
	private TextField operando1;
	
	@FXML
	private TextField operando2;
	
	@FXML
	private TextField resultado;
	
	@FXML
	private void pulsarSuma() {
		sumar();
	}
	
	@FXML
	private void pulsarResta() {
		restar();
	}
	
	@FXML
	private void pulsarMultiplicacion() {
		multiplicar();
	}
	
	@FXML
	private void pulsarDivision() {
		dividir();
	}
	
	private void sumar()
	{
		int op1 = Integer.parseInt(operando1.getText());
		int op2 = Integer.parseInt(operando2.getText());
		int res = op1 + op2;
		resultado.setText(Integer.toString(res));
	}
	
	private void restar()
	{
		int op1 = Integer.parseInt(operando1.getText());
		int op2 = Integer.parseInt(operando2.getText());
		int res = op1 - op2;
		resultado.setText(Integer.toString(res));
	}
	
	private void multiplicar()
	{
		int op1 = Integer.parseInt(operando1.getText());
		int op2 = Integer.parseInt(operando2.getText());
		int res = op1 * op2;
		resultado.setText(Integer.toString(res));
	}
	
	private void dividir()
	{
		double op1 = Double.parseDouble(operando1.getText());
		double op2 = Double.parseDouble(operando2.getText());
		if(op2!=0)
		{
			double res = op1 / op2;
			resultado.setText(Double.toString(res));
		}
		else
		{
			resultado.setText("Error!!!");
		}
	}
}
