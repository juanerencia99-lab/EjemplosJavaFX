public class MainApp
{
    public static void main(String[] args)
    {
        Factura f1 = FactoriaFacturas.getFactura("normal");
        f1.setId(1);
        f1.setImporte(100);
        System.out.println(f1.getImporteIva());

        Factura f2 = FactoriaFacturas.getFactura("reducido");
        f2.setId(1);
        f2.setImporte(100);
        System.out.println(f2.getImporteIva());
    }
}
