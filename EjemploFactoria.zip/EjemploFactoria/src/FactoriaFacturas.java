public class FactoriaFacturas
{
    private FactoriaFacturas()
    {

    }

    public static Factura getFactura(String tipo)
    {
        if (tipo.equals("normal"))
        {
            return new FacturaIva();
        }
        else if(tipo.equals("reducido"))
        {
            return new FacturaIvaReducido();
        }
        else
        {
            return null;
        }
    }
}
