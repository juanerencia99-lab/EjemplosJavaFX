module com.example.mvcjavafx {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.naming;
    requires javafx.graphics;

    opens com.example.mvcjavafx to javafx.fxml;
    exports com.example.mvcjavafx;

    opens com.example.mvcjavafx.vista to javafx.graphics;
    exports com.example.mvcjavafx.vista;

    opens com.example.mvcjavafx.vista.controladores to javafx.fxml;
    exports com.example.mvcjavafx.vista.controladores;

    opens com.example.mvcjavafx.modelo.dominio to javafx.base;
    exports com.example.mvcjavafx.modelo.dominio;
}