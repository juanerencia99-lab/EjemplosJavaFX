package com.example.mvcjavafx.vista;

import com.example.mvcjavafx.controlador.Controlador;

public class Vista {
    private Controlador controlador;

    private static Vista instancia;

    public Vista()
    {

    }

    public static Vista getInstancia() {
        if (instancia == null) {
            instancia = new Vista();
        }
        return instancia;
    }

    public void setControlador(Controlador controlador)
    {
        if (controlador == null)
            throw new NullPointerException("ERROR: El controlador no puede ser nulo.");

        this.controlador=controlador;
    }

    public Controlador getControlador()
    {
        return controlador;
    }

    public void comenzar() {
        LanzadorVentanaPrincipal.comenzar();
        getControlador().terminar();
    }

    public void terminar() {

        System.out.println("Hasta Luego!!");

    }
}
