package com.example.mvcjavafx.modelo;

import com.example.mvcjavafx.modelo.dominio.Persona;
import com.example.mvcjavafx.modelo.negocio.Personas;

import javax.naming.OperationNotSupportedException;
import java.util.ArrayList;

public class Modelo{

    private static Personas personas;

    public Modelo()
    {
        comenzar();
    }

    public void comenzar()
    {
        personas = new Personas();
    }

    public void terminar()
    {
        personas.terminar();
        System.out.println("Modelo terminado.");
    }

    public void insertar(Persona persona) throws OperationNotSupportedException
    {
        personas.insertar(persona);
    }

    public void borrar(Persona persona) throws OperationNotSupportedException
    {
        personas.borrar(persona);
    }
    public ArrayList<Persona> getPersonas()
    {
        return personas.get();
    }
}
