package com.example.mvcjavafx.controlador;

import com.example.mvcjavafx.modelo.Modelo;
import com.example.mvcjavafx.modelo.dominio.Persona;
import com.example.mvcjavafx.vista.Vista;

import javax.naming.OperationNotSupportedException;
import java.util.ArrayList;

public class Controlador {

    private Modelo modelo;
    private Vista vista;

    public Controlador(Modelo modelo, Vista vista)
    {
        if (modelo==null)
            throw new NullPointerException("ERROR: El modelo no puede ser nulo.");

        if (vista==null)
            throw new NullPointerException("ERROR: La vista no puede ser nula.");

        this.modelo=modelo;
        this.vista=vista;
        vista.setControlador(this);
    }

    public void comenzar()
    {
        modelo.comenzar();
        vista.comenzar();
    }

    public void terminar()
    {
        modelo.terminar();
        vista.terminar();
    }

    public void insertar(Persona persona) throws OperationNotSupportedException
    {
        modelo.insertar(persona);
    }

    public void borrar(Persona persona) throws OperationNotSupportedException
    {
        modelo.borrar(persona);
    }

    public ArrayList<Persona> getPersonas()
    {
        return modelo.getPersonas();
    }

}
