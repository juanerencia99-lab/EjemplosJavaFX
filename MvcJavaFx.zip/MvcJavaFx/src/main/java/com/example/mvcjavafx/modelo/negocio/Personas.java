package com.example.mvcjavafx.modelo.negocio;

import com.example.mvcjavafx.modelo.dominio.Persona;

import javax.naming.OperationNotSupportedException;
import java.util.ArrayList;
import java.util.List;

public class Personas
{
    private ArrayList<Persona> coleccionPersonas;

    public Personas()
    {
        comenzar();
    }

    public void comenzar()
    {
        coleccionPersonas=new ArrayList<Persona>();
    }

    public void terminar()
    {

    }

    public ArrayList<Persona> get() {
        return coleccionPersonas;
    }

    public void insertar(Persona persona) throws OperationNotSupportedException {
        if (persona == null) {
            throw new NullPointerException("ERROR: No se puede insertar un hu�sped nulo.");
        }

        if (coleccionPersonas.contains(persona))
            throw new OperationNotSupportedException("ERROR: Ya existe un hu�sped con ese dni.");

        coleccionPersonas.add(persona);
        System.out.println("Persona añadida.");
    }

    public void borrar(Persona persona) throws OperationNotSupportedException {
        if (persona == null) {
            throw new NullPointerException("ERROR: No se puede borrar un hu�sped nulo.");
        }

        if (!coleccionPersonas.contains(persona))
            throw new OperationNotSupportedException("ERROR: No existe ning�n hu�sped como el indicado.");

        coleccionPersonas.remove(persona);
        System.out.println("Persona eliminada.");
    }

}
