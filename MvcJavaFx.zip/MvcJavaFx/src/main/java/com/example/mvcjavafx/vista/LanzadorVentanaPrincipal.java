package com.example.mvcjavafx.vista;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

import com.example.mvcjavafx.vista.recursos.LocalizadorRecursos;

public class LanzadorVentanaPrincipal extends Application {

    public static void comenzar() {
        launch(LanzadorVentanaPrincipal.class);
    }

    @Override
    public void start(Stage escenarioPrincipal) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(LocalizadorRecursos.class.getResource("ListadoView.fxml"));
            Parent raiz = fxmlLoader.load();
            Scene escena = new Scene(raiz);
            escenarioPrincipal.setTitle("Gestión de personas");
            escenarioPrincipal.setScene(escena);
            escenarioPrincipal.show();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
}
