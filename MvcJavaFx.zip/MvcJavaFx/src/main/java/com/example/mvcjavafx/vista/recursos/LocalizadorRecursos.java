package com.example.mvcjavafx.vista.recursos;

public interface LocalizadorRecursos {
}
