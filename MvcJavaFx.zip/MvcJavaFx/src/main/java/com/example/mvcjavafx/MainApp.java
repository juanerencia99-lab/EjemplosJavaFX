package com.example.mvcjavafx;

import com.example.mvcjavafx.controlador.Controlador;
import com.example.mvcjavafx.modelo.Modelo;
import com.example.mvcjavafx.vista.Vista;

public class MainApp {
    public static void main(String[] args) {
        System.out.println("Programa para la Gestion de Personas");
        Modelo modelo=new Modelo();
        Vista vista = Vista.getInstancia();
        Controlador controlador = new Controlador(modelo, vista);
        controlador.comenzar();
    }
}
