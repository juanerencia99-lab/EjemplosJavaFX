module com.example.ventanasjavafx {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.ventanasjavafx to javafx.fxml;
    exports com.example.ventanasjavafx;

    opens com.example.ventanasjavafx.controllers to javafx.fxml;
    exports  com.example.ventanasjavafx.controllers;

    opens com.example.ventanasjavafx.models to javafx.base;
    exports com.example.ventanasjavafx.models;
}