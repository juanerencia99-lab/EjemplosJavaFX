package com.example.ventanasjavafx.controllers;

import com.example.ventanasjavafx.views.LocalizadorRecursos;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Circle;
import javafx.stage.Modality;
import javafx.stage.Stage;
import com.example.ventanasjavafx.models.Pelota;

public class ControllerVentana1 {

    @FXML
    private Button btnV2;

    @FXML
    private Button btnV3;

    @FXML
    private Circle figuraPelota;
    
    private Pelota p;
    
    public void setPelota(Pelota p)
    {
    	this.p = p;
    }
    
    public void dibujarPelota()
    {
    	this.figuraPelota.setFill(Paint.valueOf(this.p.getColor()));
    }

    @FXML
    void AbrirVentana2(ActionEvent event) 
    {
    	try {
			FXMLLoader fxmlLoader = new FXMLLoader(LocalizadorRecursos.class.getResource("VistaVentana2.fxml"));
			Parent raiz = fxmlLoader.load();
			Scene escena = new Scene(raiz);
			
			ControllerVentana2 cV2 = fxmlLoader.getController();
			this.p.setColor("#c1ff00");
			cV2.setPelota(this.p);
			cV2.dibujarPelota();
						
			//*** Creando el nuevo escenario (ventana) ***//
            
			/*
			Stage nuevoEscenario=new Stage();            
            nuevoEscenario.initModality(Modality.APPLICATION_MODAL);
            nuevoEscenario.setTitle("Ventana 2");
            
            nuevoEscenario.setScene(escena);            
            nuevoEscenario.show();
            
            Stage escenarioActual = (Stage) ((Node) event.getSource()).getScene().getWindow();
	    	escenarioActual.close();
	    	*/
			
	    	/************************************/
	    	/*** Usando el mismo escenario ***/
			
	    	Stage escenario = (Stage) ((Node) event.getSource()).getScene().getWindow();
	    	escenario.setTitle("Ventana 2");
	    	escenario.setScene(escena);            
	    	escenario.show();
	    	
	    	/**************************************/
            
		} catch(Exception e) {
			e.printStackTrace();
		}
    }

    @FXML
    void AbrirVentana3(ActionEvent event) {
    	try {
			FXMLLoader fxmlLoader = new FXMLLoader(LocalizadorRecursos.class.getResource("VistaVentana3.fxml"));
			Parent raiz = fxmlLoader.load();
			Scene escena = new Scene(raiz);
			
			ControllerVentana3 cV3 = fxmlLoader.getController();
			this.p.setColor("#ff003a");
			cV3.setPelota(this.p);
			cV3.dibujarPelota();
			
			/*
			//Creamos el escenario
            Stage nuevoEscenario=new Stage();            
            nuevoEscenario.initModality(Modality.APPLICATION_MODAL);
            nuevoEscenario.setTitle("Ventana 3");
            //Establecemos la escena
            nuevoEscenario.setScene(escena);            
            nuevoEscenario.show();
            
            Stage escenarioActual = (Stage) ((Node) event.getSource()).getScene().getWindow();
	    	escenarioActual.close();
	    	*/
			
			/************************************/
	    	/*** Usando el mismo escenario ***/
			
	    	Stage escenario = (Stage) ((Node) event.getSource()).getScene().getWindow();
	    	escenario.setTitle("Ventana 3");
	    	escenario.setScene(escena);            
	    	escenario.show();
	    	
	    	/**************************************/
            
		} catch(Exception e) {
			e.printStackTrace();
		}
    }

}