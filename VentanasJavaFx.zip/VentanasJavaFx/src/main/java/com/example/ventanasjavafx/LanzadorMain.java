package com.example.ventanasjavafx;

public class LanzadorMain {

	public static void main(String[] args) {
		MainApp.main(args);
	}

}
