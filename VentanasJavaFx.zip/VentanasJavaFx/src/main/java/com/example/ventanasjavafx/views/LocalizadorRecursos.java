package com.example.ventanasjavafx.views;

public interface LocalizadorRecursos {
}
