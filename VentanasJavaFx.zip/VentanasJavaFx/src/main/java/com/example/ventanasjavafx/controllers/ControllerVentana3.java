package com.example.ventanasjavafx.controllers;

import com.example.ventanasjavafx.views.LocalizadorRecursos;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Circle;
import javafx.stage.Modality;
import javafx.stage.Stage;
import com.example.ventanasjavafx.models.Pelota;

public class ControllerVentana3 {

    @FXML
    private Button btnV2;

    @FXML
    private Button btnV3;

    @FXML
    private Circle figuraPelota;
    
    private Pelota p;
    
    public void setPelota(Pelota p)
    {
    	this.p = p;
    }
    
    public void dibujarPelota()
    {
    	this.figuraPelota.setFill(Paint.valueOf(this.p.getColor()));
    }

    @FXML
    void AbrirVentana1(ActionEvent event) 
    {
    	try {
			FXMLLoader fxmlLoader = new FXMLLoader(LocalizadorRecursos.class.getResource("VistaVentana1.fxml"));
			Parent raiz = fxmlLoader.load();
			Scene escena = new Scene(raiz);
			
			ControllerVentana1 cV1 = fxmlLoader.getController();
			this.p.setColor("#0055ff");
			cV1.setPelota(this.p);
			cV1.dibujarPelota();
						
			//Creamos el escenario
            Stage nuevoEscenario=new Stage();            
            nuevoEscenario.initModality(Modality.APPLICATION_MODAL);
            nuevoEscenario.setTitle("Ventana 1");
            //Establecemos la escena
            nuevoEscenario.setScene(escena);            
            nuevoEscenario.show();
            
            //Stage escenarioActual = (Stage) ((Node) event.getSource()).getScene().getWindow();
	    	//escenarioActual.close();
            
		} catch(Exception e) {
			e.printStackTrace();
		}
    }

    @FXML
    void AbrirVentana2(ActionEvent event) {
    	try {
			FXMLLoader fxmlLoader = new FXMLLoader(LocalizadorRecursos.class.getResource("VistaVentana2.fxml"));
			Parent raiz = fxmlLoader.load();
			Scene escena = new Scene(raiz);
			
			ControllerVentana2 cV2 = fxmlLoader.getController();
			this.p.setColor("#c1ff00");
			cV2.setPelota(this.p);
			cV2.dibujarPelota();
						
			//Creamos el escenario
            Stage nuevoEscenario=new Stage();            
            nuevoEscenario.initModality(Modality.APPLICATION_MODAL);
            nuevoEscenario.setTitle("Ventana 2");
            //Establecemos la escena
            nuevoEscenario.setScene(escena);            
            nuevoEscenario.show();
            
            //Stage escenarioActual = (Stage) ((Node) event.getSource()).getScene().getWindow();
	    	//escenarioActual.close();
            
		} catch(Exception e) {
			e.printStackTrace();
		}
    }

}