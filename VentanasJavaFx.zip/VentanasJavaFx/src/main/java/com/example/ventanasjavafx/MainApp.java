package com.example.ventanasjavafx;

import com.example.ventanasjavafx.views.LocalizadorRecursos;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import com.example.ventanasjavafx.controllers.ControllerVentana1;
import com.example.ventanasjavafx.controllers.ControllerVentana2;
import com.example.ventanasjavafx.models.Pelota;

public class MainApp extends Application {

	@Override
	public void start(Stage escenarioPrincipal) {
		try {
			FXMLLoader fxmlLoader = new FXMLLoader(LocalizadorRecursos.class.getResource("VistaVentana1.fxml"));
			Parent raiz = fxmlLoader.load();
			Scene escena = new Scene(raiz);
			
			ControllerVentana1 cV1 = fxmlLoader.getController();
			
			Pelota p = new Pelota("#0055ff");
			
			cV1.setPelota(p);
			cV1.dibujarPelota();
			
			escenarioPrincipal.setTitle("Ventana1");
			escenarioPrincipal.setScene(escena);
			escenarioPrincipal.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		launch(args);
	}
}
