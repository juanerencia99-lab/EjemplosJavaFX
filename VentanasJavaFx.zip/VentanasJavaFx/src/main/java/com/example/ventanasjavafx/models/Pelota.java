package com.example.ventanasjavafx.models;

public class Pelota 
{
	private String color;
	
	public Pelota(String color)
	{
		this.setColor(color);
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	@Override
	public String toString() {
		return "La pelota es de color..."+this.color;
	}
	
	
}
