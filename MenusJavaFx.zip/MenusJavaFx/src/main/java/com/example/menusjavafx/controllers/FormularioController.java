package com.example.menusjavafx.controllers;

import com.example.menusjavafx.models.Persona;
import com.example.menusjavafx.utilidades.Dialogos;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.scene.control.Alert.AlertType;

public class FormularioController {

    @FXML
    private Button btnGuardar;

    @FXML
    private TextField campoApellidos;

    @FXML
    private TextField campoEdad;

    @FXML
    private TextField campoNombre;

    @FXML
    private Label labelTitulo;
    
    private ObservableList<Persona> listaPersonas;
    
    private Persona registro;
    
    public void setListado(ObservableList<Persona> listaPersonas)
    {
    	this.listaPersonas = listaPersonas;
    }

    public void setRegistro(Persona p)
    {
    	this.registro = p;
    	
    	if(this.registro!=null)
    	{
    		labelTitulo.setText("Editar persona");
    		this.campoNombre.setText(this.registro.getNombre());
    		this.campoApellidos.setText(this.registro.getApellidos());
    		this.campoEdad.setText(Integer.toString(this.registro.getEdad()));
    	}
    	else
    	{
    		labelTitulo.setText("Añadir persona");
    	}
    }
    
    public Persona getRegistro()
    {
    	return this.registro;
    }
        
    @FXML
    void Guardar(ActionEvent event) 
    {
    	try
    	{
	    	String nombre = this.campoNombre.getText();
	    	String apellidos = this.campoApellidos.getText();
	    	int edad = Integer.parseInt(this.campoEdad.getText());
	    	
	    	if(this.registro == null) // Añadimos una nueva persona
	    	{
	    		Persona p = new Persona(nombre, apellidos, edad);
		    	
		    	if(this.listaPersonas.contains(p)==false)
		    	{    		    		
		    		Dialogos.mostrarDialogoInformacion("Información", "Persona añadida correctamente.", null);

					this.registro = p;
		        	Stage escenarioActual = (Stage) ((Node) event.getSource()).getScene().getWindow();
			    	escenarioActual.close();
		    	}
		    	else
		    	{
					Dialogos.mostrarDialogoError("Error", "La persona ya existe.", null);
				}
	    	}
	    	else // Modificamos una persona existente
	    	{
	    		this.registro.setNombre(nombre);
	        	this.registro.setApellidos(apellidos);
	        	this.registro.setEdad(edad);
	        	
	        	Dialogos.mostrarDialogoInformacion("Información", "Persona modificada correctamente.", null);
	        	Stage escenarioActual = (Stage) ((Node) event.getSource()).getScene().getWindow();
		    	escenarioActual.close();
	        }	
    	}
    	catch(NumberFormatException e)
    	{
			Dialogos.mostrarDialogoError("Error", "La edad tiene que ser un número.", null);

    	}
    	catch(Exception e)
    	{
			Dialogos.mostrarDialogoError("Error", e.getMessage(), null);

    	}
    }
}
