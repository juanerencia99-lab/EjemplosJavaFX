package com.example.menusjavafx;

import com.example.menusjavafx.utilidades.Dialogos;
import com.example.menusjavafx.views.LocalizadorRecursos;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

public class MainApp extends Application {
	
	public static void main(String[] args) {
		launch(args);
	}
	
	@Override
	public void start(Stage escenarioPrincipal) {
		try {
			FXMLLoader fxmlLoader = new FXMLLoader(LocalizadorRecursos.class.getResource("ListadoView.fxml"));
			Parent raiz = fxmlLoader.load();
			Scene escena = new Scene(raiz);
			escenarioPrincipal.setTitle("Gestión de personas");
			escenarioPrincipal.setOnCloseRequest(e -> confirmarSalida(escenarioPrincipal, e));
			escenarioPrincipal.setScene(escena);

			escenarioPrincipal.show();

		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	private void confirmarSalida(Stage escenario, WindowEvent e) {
		if (Dialogos.mostrarDialogoConfirmacion("Salir", "¿Estás seguro de que quieres salir de la aplicación?", escenario)) {
			escenario.close();
		}
		else {
			e.consume();
		}
	}
}