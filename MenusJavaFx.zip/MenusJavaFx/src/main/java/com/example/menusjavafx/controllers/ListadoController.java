package com.example.menusjavafx.controllers;

import java.net.URL;
import java.util.ResourceBundle;

import com.example.menusjavafx.models.Persona;
import com.example.menusjavafx.utilidades.Dialogos;
import com.example.menusjavafx.views.LocalizadorRecursos;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class ListadoController implements Initializable{

    @FXML
    private Button btnAdd;

    @FXML
    private Button btnDelete;

    @FXML
    private Button btnEdit;

    @FXML
    private TextField campoBuscar;
    
    @FXML
    private TextField campoApellidos;

    @FXML
    private TextField campoEdad;

    @FXML
    private TextField campoNombre;

    @FXML
    private TableColumn<Persona,String> colApellidos;

    @FXML
    private TableColumn<Persona,Integer> colEdad;

    @FXML
    private TableColumn<Persona,String> colNombre;

    @FXML
    private TableView<Persona> tablaPersonas;
    
    private ObservableList<Persona> listaPersonas;
    private ObservableList<Persona> listaPersonasVisible;
    
    private Persona registro;
    
    private String filtro;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {		
    	this.colNombre.setCellValueFactory(new PropertyValueFactory<Persona,String>("nombre"));
		this.colApellidos.setCellValueFactory(new PropertyValueFactory<Persona,String>("apellidos"));
		this.colEdad.setCellValueFactory(new PropertyValueFactory<Persona,Integer>("edad"));
    
		this.filtro = "";
		listaPersonas = FXCollections.observableArrayList();
		listaPersonasVisible = FXCollections.observableArrayList();
		this.tablaPersonas.setItems(listaPersonasVisible);
		this.refrescarTabla();
    }     

    @FXML
    void Buscar(KeyEvent event) 
    {
    	this.filtro = this.campoBuscar.getText();
    	this.refrescarTabla();
    }
            
    @FXML
    void AddPersona(ActionEvent event) 
    {
    	try
    	{    		    		
    		FXMLLoader fxmlLoader = new FXMLLoader(LocalizadorRecursos.class.getResource("FormularioView.fxml"));
			Parent raiz = fxmlLoader.load();
			Scene escena = new Scene(raiz);
			
			FormularioController cF = fxmlLoader.getController();
			cF.setListado(this.listaPersonas);
			cF.setRegistro(null);
						
			Stage nuevoEscenario=new Stage();            
            nuevoEscenario.initModality(Modality.APPLICATION_MODAL);
            nuevoEscenario.setTitle("Añadir persona...");
            
            nuevoEscenario.setScene(escena);            
            nuevoEscenario.showAndWait();
               
            Persona p = cF.getRegistro();
            this.listaPersonas.add(p);
            this.refrescarTabla();
    	}
    	catch(Exception e)
    	{
    		Dialogos.mostrarDialogoError("Error", e.getMessage(), null);
    	}
    }

    @FXML
    void DeletePersona(ActionEvent event) 
    {
    	if(this.registro == null)
    	{
    		Dialogos.mostrarDialogoError("Error", "No has seleccionado ninguna persona.", null);
    	}
    	else
    	{
    		this.listaPersonas.remove(this.registro);
			Dialogos.mostrarDialogoInformacion("Información", "Persona eliminada correctamente.", null);
			this.refrescarTabla();
    	}
    }

    @FXML
    void EditPersona(ActionEvent event) 
    {
    	if(this.registro == null)
    	{
    		Dialogos.mostrarDialogoError("Error", "No has seleccionado ninguna persona.", null);
    	}
    	else
    	{
    		try
        	{    		    		
        		FXMLLoader fxmlLoader = new FXMLLoader(LocalizadorRecursos.class.getResource("FormularioView.fxml"));
    			Parent raiz = fxmlLoader.load();
    			Scene escena = new Scene(raiz);
    			
    			FormularioController cF = fxmlLoader.getController();
    			cF.setListado(this.listaPersonas);
    			cF.setRegistro(this.registro);
    						
    			Stage nuevoEscenario=new Stage();            
                nuevoEscenario.initModality(Modality.APPLICATION_MODAL);
                nuevoEscenario.setTitle("Editar persona...");
                
                nuevoEscenario.setScene(escena);            
                nuevoEscenario.showAndWait();
                
                this.refrescarTabla();
        	}
        	catch(Exception e)
        	{
        		Dialogos.mostrarDialogoError("Error", e.getMessage(), null);
        	}
    	}
    }

    @FXML
    void Seleccionar(MouseEvent event) 
    {
    	this.registro = this.tablaPersonas.getSelectionModel().getSelectedItem();
    }

    private void refrescarTabla()
    {
    	this.registro = null;
    	this.tablaPersonas.getSelectionModel().select(null);
    	
    	this.listaPersonasVisible.clear();
    	
    	for(Persona p:this.listaPersonas)
    	{
    		if(this.filtro.isEmpty() || p.getNombre().toLowerCase().contains(filtro.toLowerCase()))
    		{
    			this.listaPersonasVisible.add(p);
    		}
    	}
    	    	
    	this.tablaPersonas.refresh();
    }
}