package com.example.menusjavafx.views;

public interface LocalizadorRecursos {
}
