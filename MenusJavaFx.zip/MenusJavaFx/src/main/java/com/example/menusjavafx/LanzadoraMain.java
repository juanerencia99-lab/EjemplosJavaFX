package com.example.menusjavafx;

public class LanzadoraMain {

	public static void main(String[] args) {
		MainApp.main(args);
	}

}
