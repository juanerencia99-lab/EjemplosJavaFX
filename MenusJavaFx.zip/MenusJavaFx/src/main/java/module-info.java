module com.example.menusjavafx {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.menusjavafx to javafx.fxml;
    exports com.example.menusjavafx;

    opens com.example.menusjavafx.controllers to javafx.fxml;
    exports com.example.menusjavafx.controllers;

    opens com.example.menusjavafx.models to javafx.base;
    exports com.example.menusjavafx.models;
}