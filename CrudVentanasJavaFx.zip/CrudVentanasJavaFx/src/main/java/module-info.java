module com.example.crudventanasjavafx {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.crudventanasjavafx to javafx.fxml;
    exports com.example.crudventanasjavafx;

    opens com.example.crudventanasjavafx.controllers to javafx.fxml;
    exports com.example.crudventanasjavafx.controllers;

    opens com.example.crudventanasjavafx.models to javafx.base;
    exports com.example.crudventanasjavafx.models;
}