package com.example.crudventanasjavafx.models;

import java.util.Objects;

public class Persona 
{
	private String nombre;
	private String apellidos;
	private int edad;
	
	public Persona(String nombre, String apellidos, int edad) throws Exception
	{
		this.setNombre(nombre);
		this.setApellidos(apellidos);
		this.setEdad(edad);
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) throws Exception {
		
		if(nombre==null || nombre.isEmpty())
		{
			throw new Exception("El nombre no puede estar vacío.");
		}
		
		this.nombre = nombre;
	}

	public String getApellidos() {
		return apellidos;
	}

	public void setApellidos(String apellidos) throws Exception {
		
		if(apellidos==null || apellidos.isEmpty())
		{
			throw new Exception("Los apellidos no pueden estar vacíos.");
		}
		
		this.apellidos = apellidos;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) throws Exception {
		
		if(edad <= 0)
		{
			throw new Exception("La edad debe ser un número positivo");
		}
		
		this.edad = edad;
	}

	@Override
	public int hashCode() {
		return Objects.hash(apellidos, edad, nombre);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Persona other = (Persona) obj;
		return Objects.equals(apellidos, other.apellidos) && edad == other.edad && Objects.equals(nombre, other.nombre);
	}
}
