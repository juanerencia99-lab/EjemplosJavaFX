package com.example.crudventanasjavafx.views;

public interface LocalizadorRecursos {
}
