package com.example.crudventanasjavafx;

public class LanzadoraMain {

	public static void main(String[] args) {
		MainApp.main(args);
	}

}
