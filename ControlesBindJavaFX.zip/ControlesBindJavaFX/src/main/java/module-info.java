module com.example.controlesbindjavafx {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.controlesbindjavafx to javafx.fxml;
    exports com.example.controlesbindjavafx;

    opens com.example.controlesbindjavafx.controllers to javafx.fxml;
    exports com.example.controlesbindjavafx.controllers;
}