package com.example.controlesbindjavafx.controllers;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Slider;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

public class BindController implements Initializable{

	@FXML
    private TextField campoTxtG12;

    @FXML
    private TextField campoTxtG23;

    @FXML
    private TextField campoTxtG41;

    @FXML
    private TextField campoTxtG42;

    @FXML
    private Slider slideG11;

    @FXML
    private Slider slideG21;

    @FXML
    private Slider slideG22;

    @FXML
    private Slider slideG31;

    @FXML
    private Slider slideG32;

    @FXML
    void MoverSlide(MouseEvent event) {

    	this.campoTxtG12.setText(Double.toString(this.slideG11.getValue()));
    	
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
		this.slideG21.valueProperty().bind(this.slideG22.valueProperty());
		campoTxtG23.textProperty().bind(this.slideG22.valueProperty().asString());
        
		
		this.slideG31.valueProperty().bindBidirectional(this.slideG32.valueProperty());
				
		this.campoTxtG41.textProperty().bindBidirectional(this.campoTxtG42.textProperty());
    } 
}




    
    