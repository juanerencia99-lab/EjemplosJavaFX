package com.example.controlesbindjavafx.views;

public interface LocalizadorRecursos {
}
