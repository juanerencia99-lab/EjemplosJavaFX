package com.example.controlesbindjavafx;

public class LanzadoraMain {

	public static void main(String[] args) {
		MainApp.main(args);
	}

}
