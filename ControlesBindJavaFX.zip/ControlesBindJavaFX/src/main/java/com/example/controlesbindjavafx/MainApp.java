package com.example.controlesbindjavafx;

import com.example.controlesbindjavafx.views.LocalizadorRecursos;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class MainApp extends Application {
	
	public static void main(String[] args) {
		launch(args);
	}
	
	@Override
	public void start(Stage escenarioPrincipal) {
		try {
			FXMLLoader fxmlLoader = new FXMLLoader(LocalizadorRecursos.class.getResource("BindView.fxml"));
			Parent raiz = fxmlLoader.load();
			Scene escena = new Scene(raiz);
			escenarioPrincipal.setTitle("Controles bind");
			escenarioPrincipal.setScene(escena);
			escenarioPrincipal.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
}